#Created by Muhammad Na'im bin Samat
Testing on https://pos.com.my/send/ratecalculator

Consists of 2 Questions

Q1 - API testing using postman

Q2 - Automation scripting in Java using Selenium

All tasks were committed into github - https://github.com/naimsamat92/TakeHomeAssessment